package com.example.zanemobilescheduler;

import android.content.Intent;
import android.os.Bundle;

import com.example.zanemobilescheduler.Assessment.Assessment;
import com.example.zanemobilescheduler.Course.Course;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {
        Button termsListButton;
    Button nukeDbButton;
    Button popDbButton;
    FullDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nukeDbButton = findViewById(R.id.clearDbBtn);
        nukeDbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                db = FullDatabase.getInstance(getApplicationContext());
                db.termDao().nukeTermTable();
                db.courseDao().nukeCourseTable();
                db.assessmentDao().nukeAssessmentTable();
                System.out.println("Duke Nuke 'em");
                updateStatusViews();

                }
        });

        popDbButton = findViewById(R.id.popDbBtn);
        popDbButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                 PopulateFullDatabase popDb = new PopulateFullDatabase();
                 popDb.populate(getApplicationContext());
                updateStatusViews();
            }
        });

        termsListButton = findViewById(R.id.viewTermsBtn);
        termsListButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openTermsListActivity();
            }
        });
        updateStatusViews();


    }
    public void openTermsListActivity(){
        Intent intent = new Intent(getApplicationContext(), TermsListSecondActivity.class);
        startActivity(intent);
    }

    private void updateStatusViews() {
        db = FullDatabase.getInstance(getApplicationContext());
        System.out.println("In Status View");
        int coursesInProgress = 0;
        int coursesCompleted = 0;
        int coursesPlan = 0;
        int coursesDropped = 0;
        int assessmentsPending = 0;
        int assessmentsPassed = 0;
        int assessmentsFailed = 0;
        try{
            System.out.println("In Try View");
            List<Course> courseListInProgress = db.courseDao().getAllCourses("In Progress");
            coursesInProgress = courseListInProgress.size();

            List<Course> courseListCompleted = db.courseDao().getAllCourses("Completed");
            coursesCompleted = courseListCompleted.size();

            List<Course> courseListPlan = db.courseDao().getAllCourses("Plan to Take");
            coursesPlan = courseListPlan.size();

            List<Assessment> AssessmentListPending = db.assessmentDao().getAllAssessments("Pending");
            assessmentsPending = AssessmentListPending.size();

            List<Assessment> AssessmentListPassed = db.assessmentDao().getAllAssessments("Passed");
            assessmentsPassed = AssessmentListPassed.size();

            List<Assessment> AssessmentListFailed = db.assessmentDao().getAllAssessments("Failed");
            assessmentsFailed = AssessmentListFailed.size();

            System.out.println(coursesCompleted);
            System.out.println(assessmentsPending);


        }
        catch (Exception e) {
            e.printStackTrace();
                    }

        TextView coursesInProgressTextView =   findViewById(R.id.in_progress_num);
        TextView coursesCompletedTextView =   findViewById(R.id.complete_num);
        TextView coursesPlanTextView =   findViewById(R.id.plan_num);
        TextView coursesDroppedTextView =  findViewById(R.id.dropped_num);
        TextView assessmentsPendingTextView =  findViewById(R.id.pending_num);
        TextView assessmentsPassedTextView =   findViewById(R.id.passed_num);
        TextView assessmentsFailedTextView =   findViewById(R.id.failed_assessment_num);

        coursesInProgressTextView.setText(String.valueOf(coursesInProgress));
        coursesCompletedTextView.setText(String.valueOf(coursesCompleted));
        coursesPlanTextView.setText(String.valueOf(coursesPlan));
        coursesDroppedTextView.setText(String.valueOf(coursesDropped));
        assessmentsPendingTextView.setText(String.valueOf(assessmentsPending));
        assessmentsPassedTextView.setText(String.valueOf(assessmentsPassed));
        assessmentsFailedTextView.setText(String.valueOf(assessmentsFailed));



        }
    }






