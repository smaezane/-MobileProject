package com.example.zanemobilescheduler.Course;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface CourseDao {
    @Query("SELECT * FROM course_table  WHERE term_id_fk = :termId")
    List<Course> getCourseList(int termId);
   

    @Query("SELECT * FROM course_table WHERE course_id = :courseId")
    Course getCourse(int courseId);

    @Query("SELECT * FROM course_table")
    List<Course> getAllCourses();

    @Query("SELECT * FROM course_table WHERE course_status = :courseStatus")
    List<Course> getAllCourses(String courseStatus);

    @Insert
    void insertCourse(Course course);

    @Insert
    void insertAll(Course... course);

    @Update
    void updateCourse(Course course);

    @Delete
    void deleteCourse(Course course);

    @Query("DELETE FROM course_table")
    public void nukeCourseTable();

    @Query("SELECT * FROM course_table")
    List<Course> getCourseList();
}
