package com.example.zanemobilescheduler.Assessment;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.zanemobilescheduler.Course.CourseEditActivity;
import com.example.zanemobilescheduler.FullDatabase;
import com.example.zanemobilescheduler.MainActivity;
import com.example.zanemobilescheduler.R;
import com.example.zanemobilescheduler.Term.TermDetailActivity;
import com.example.zanemobilescheduler.Term.TermEditActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AssessmentDetailActivity extends AppCompatActivity {
    FullDatabase db;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment_detail);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        Editfab();
        populateInputs();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void Editfab() {
        int assessment_id = getIntent().getExtras().getInt("assessmentId");
        System.out.println("Here is your extra in Edit fab " + assessment_id);

        final Intent intent = new Intent(getApplicationContext(), AssessmentEditActivity.class);
        intent.putExtra("assessmentId", assessment_id);
        FloatingActionButton fab1 = (FloatingActionButton) findViewById(R.id.edit_assessment_fab);
        fab1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intent);
            }
        });
    }
    private void populateInputs() {

        String assessmentTitle;
        String assessmentType;
        Date assessmentDueDate;
        String pattern = "E, MMM dd, YYYY";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        db = FullDatabase.getInstance(getApplicationContext());

        int assessment_id = getIntent().getExtras().getInt("assessmentId");
        System.out.println("Extra from previous Activity: " + assessment_id);

        Assessment assessment = db.assessmentDao().getAssessment(assessment_id);

        assessmentTitle = assessment.getAssessment_name();
        assessmentType = assessment.getAssessment_type();
        assessmentDueDate = assessment.getAssessment_due_date();

        System.out.println(assessmentTitle + assessmentDueDate);

        String startDateFormatted = simpleDateFormat.format(assessmentDueDate);

        TextView assessmentTitleTextView = findViewById(R.id.assessment_title);
        TextView assessmentTypeTextView = findViewById(R.id.assessment_type);
        TextView assessmentStartTextView = findViewById(R.id.assessment_due_date);

        assessmentTitleTextView.setText(assessmentTitle);
        assessmentTypeTextView.setText(assessmentType);
        assessmentStartTextView.setText(startDateFormatted);


    }

    }


