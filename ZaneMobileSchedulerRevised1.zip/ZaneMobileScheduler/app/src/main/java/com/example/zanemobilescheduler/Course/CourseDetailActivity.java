package com.example.zanemobilescheduler.Course;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.zanemobilescheduler.Assessment.Assessment;
import com.example.zanemobilescheduler.Assessment.AssessmentDetailActivity;
import com.example.zanemobilescheduler.FullDatabase;
import com.example.zanemobilescheduler.MainActivity;
import com.example.zanemobilescheduler.NotesActivity;
import com.example.zanemobilescheduler.R;
import com.example.zanemobilescheduler.Term.Term;
import com.example.zanemobilescheduler.Term.TermDetailActivity;
import com.example.zanemobilescheduler.Term.TermEditActivity;
import com.example.zanemobilescheduler.TermsListSecondActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;


import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class CourseDetailActivity extends AppCompatActivity   {
    Button notesButton;
    int course_id;
    int assessment_id;
    FullDatabase db;
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        course_id = getIntent().getExtras().getInt("courseId");
        System.out.println("Extra from previous Activity: " + course_id);

        setContentView(R.layout.activity_course_detail);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        listView = findViewById(R.id.assessment_list_view);
        db= FullDatabase.getInstance(getApplicationContext());
        List<Assessment> allAssessments = db.assessmentDao().getAssessmentList(course_id);
        System.out.println("Number of Rows in assessments = " + allAssessments.size());

        String[] items = new String[allAssessments.size()];
        if(!allAssessments.isEmpty()) {
            for ( int i = 0; i < allAssessments.size(); i++) {
                items[i] = allAssessments.get(i).getAssessment_name();
                System.out.println("Inside updateList loop in assessments: " + i);
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                System.out.println("Position Clicked: " + position);
                Intent intent = new Intent(getApplicationContext(), AssessmentDetailActivity.class);

                List<Assessment> courseDetailActivity = db.assessmentDao().getAssessmentList(course_id);
                assessment_id = courseDetailActivity.get(position).getAssessment_id();
                Assessment testAssessment = db.assessmentDao().getAssessment(assessment_id);
                String assessmentNAme = testAssessment.getAssessment_name();
                System.out.println("On the Course page you clicked on this assessment: " +assessmentNAme);
                intent.putExtra("assessmentId", assessment_id);
                System.out.println("assessment_id at 0: " + assessment_id);
                startActivity(intent);


            }

        });

        notesButton = findViewById(R.id.notes_button);
        notesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int course_id = getIntent().getExtras().getInt("courseId");
                final Intent intent = new Intent(getApplicationContext(), NotesActivity.class);
                intent.putExtra("courseId", course_id);
                startActivity(intent);
            }
        });

        updateList();
        updateLabels();
        Addfab();
        Editfab();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void Addfab(){
        FloatingActionButton fab = findViewById(R.id.add_assessment_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int course_id = getIntent().getExtras().getInt("courseId");
                Assessment tempAssessment1 = new Assessment();
                Calendar end;
                List<Course> courseList = db.courseDao().getCourseList();
                if (courseList == null) return;


                end = Calendar.getInstance();
                end.add(Calendar.MONTH,  +6);
                tempAssessment1.setAssessment_name("New Assessment");
                tempAssessment1.setAssessment_due_date(end.getTime());
                tempAssessment1.setAssessment_status("Pending");
                tempAssessment1.setCourse_id_fk(course_id);
                db.assessmentDao().insertAssessment(tempAssessment1);
                updateList();
                //   Snackbar.make(view, "Here's a Snackbar", Snackbar.LENGTH_LONG)
                //          .setAction("Action", null).show();
            }
        });
    }



    private void Editfab() {
        int course_id = getIntent().getExtras().getInt("courseId");
        System.out.println("Here is your extra in Edit fab " + course_id);
        final Intent intent = new Intent(getApplicationContext(), CourseEditActivity.class);
        intent.putExtra("courseId", course_id);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.edit_course_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intent);
            }
        });
    }



    private void updateLabels() {
        String courseTitle;
        Date startDate;
        Date endDate;
        String courseStatus;
        String mentorName;
        String mentorPhone;
        String mentorEmail;
        String pattern = "E, MMM dd, YYYY";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        int course_id = getIntent().getExtras().getInt("courseId");


        System.out.println("here are the extras  " + course_id);
        Course course = db.courseDao().getCourse( course_id);

        courseTitle = course.getCourse_name();
        startDate = course.getCourse_start();
        endDate = course.getCourse_end();
       courseStatus = course.getCourse_status();
        mentorName = course.getCourse_mentor_name();
        mentorPhone = course.getCourse_mentor_phone();
       mentorEmail = course.getCourse_mentor_email();

        System.out.println(courseTitle + courseStatus + mentorName + mentorPhone + mentorEmail);

        String startDateFormatted = "Start Date: " + simpleDateFormat.format(startDate);
        String endDateFormatted = "End Date: " + simpleDateFormat.format(endDate);


        TextView courseTitleTextView = findViewById(R.id.course_title);
        TextView courseStartTextView = findViewById(R.id.course_start);
        TextView courseEndTextView = findViewById(R.id.course_end);
        TextView courseStatusTextView = findViewById(R.id.status);
        TextView mentorNameTextView = findViewById(R.id.mentor_name);
        TextView mentorPhoneTextView = findViewById(R.id.mentor_phone);
        TextView mentorEmailTextView = findViewById(R.id.mentor_email);

        courseTitleTextView.setText(courseTitle);
        courseStartTextView.setText(startDateFormatted);
        courseEndTextView.setText(endDateFormatted);
        courseStatusTextView.setText("Course Status: " + courseStatus);
        System.out.println("Course Status: " + courseStatus);
        mentorNameTextView.setText("Professor " + mentorName);
        mentorPhoneTextView.setText(mentorPhone);
        mentorEmailTextView.setText(mentorEmail);

    }

    private void updateList() {
        int course_id = getIntent().getExtras().getInt("courseId");

        System.out.println("Did the extra work?? " + course_id);
        List<Assessment> allAssessments = db.assessmentDao().getAssessmentList(course_id);
        System.out.println("Number of Rows in assessments = " + allAssessments.size());

        String[] items = new String[allAssessments.size()];
        if(!allAssessments.isEmpty()) {
            for ( int i = 0; i < allAssessments.size(); i++) {
                items[i] = allAssessments.get(i).getAssessment_name();
                System.out.println("Inside updateList loop in assessments: " + i);
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);

    }
}
