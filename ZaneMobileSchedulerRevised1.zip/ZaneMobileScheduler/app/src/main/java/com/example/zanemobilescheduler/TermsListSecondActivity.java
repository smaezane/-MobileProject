package com.example.zanemobilescheduler;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.zanemobilescheduler.Term.Term;
import com.example.zanemobilescheduler.Term.TermDetailActivity;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import java.util.Calendar;
import java.util.List;

public class TermsListSecondActivity extends AppCompatActivity {

    FullDatabase db;
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_terms_list);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);


        listView = findViewById(R.id.TermsListView);
        db= FullDatabase.getInstance(getApplicationContext());

         listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
             @Override
             public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                 System.out.println("Position Clicked: " + position);
                 Intent intent = new Intent(getApplicationContext(), TermDetailActivity.class);
                 int term_id;
                 List<Term> termListActivity = db.termDao().getTermList();
                 for (Term term : termListActivity) {
                     System.out.println(term.getTerm_id());
                 }
                 term_id = termListActivity.get(position).getTerm_id();
                 System.out.println("This is the term id you picked" +term_id);

                 intent.putExtra("termId", term_id);
                 System.out.println("term_id at 0: " + term_id);
                 startActivity(intent);
             }

         });
        updateList();
        Addfab();



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void Addfab(){
        FloatingActionButton fab = findViewById(R.id.add_term_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Term tempTerm1 = new Term();
                Calendar start;
                Calendar end;

                start = Calendar.getInstance();
                end = Calendar.getInstance();
                end.add(Calendar.MONTH,  +6);
                tempTerm1.setTerm_name("New Term");
                tempTerm1.setTerm_start(start.getTime());
                tempTerm1.setTerm_end(end.getTime());
                db.termDao().insertAll(tempTerm1);
                System.out.println("Term inserted from fab");
                updateList();

            }
        });
    }





    private void updateList() {
        List<Term> allTerms = db.termDao().getAllTerms();
        System.out.println("Number of Rows = " + allTerms.size());

        String[] items = new String[allTerms.size()];
        if(!allTerms.isEmpty()) {
            for ( int i = 0; i < allTerms.size(); i++) {
                items[i] = allTerms.get(i).getTerm_name();
                System.out.println("Inside updateList loop: " + i);
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);
       // adapter.notifyDataSetChanged();
    }
}
