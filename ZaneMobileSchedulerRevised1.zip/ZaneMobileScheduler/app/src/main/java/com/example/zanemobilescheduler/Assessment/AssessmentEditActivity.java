package com.example.zanemobilescheduler.Assessment;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.zanemobilescheduler.Course.CourseDetailActivity;
import com.example.zanemobilescheduler.FullDatabase;
import com.example.zanemobilescheduler.MainActivity;
import com.example.zanemobilescheduler.MyBroadcastReceiver;
import com.example.zanemobilescheduler.R;
import com.google.android.material.snackbar.Snackbar;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class AssessmentEditActivity extends AppCompatActivity {
    FullDatabase db;
    DatePicker pickerStart;
    Button deletebutton;
    Button savebutton;
    Button alertDueDateButton;
    public static final int REQUEST_CODE = 101;
    AlarmManager alarmManager;
    PendingIntent pendingIntentDue;
    int course_id_fk;
    Spinner assessmentSpinner;


    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_assessment);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        populateInputs();

        assessmentSpinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.assessment_spinner_data, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        assessmentSpinner.setAdapter(adapter);

        alertDueDateButton = findViewById(R.id.assessment_due_date_button);
        alertDueDateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setDueDateAlarm();

                Snackbar.make(view, "Alarm Set", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });


        deletebutton = findViewById(R.id.assessment_delete_btn);
        deletebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db = FullDatabase.getInstance(getApplicationContext());
                int assessment_id = getIntent().getExtras().getInt("assessmentId");
                System.out.println("Extra from previous Activity: " + assessment_id);
                Assessment assessment = db.assessmentDao().getAssessment(assessment_id);
                course_id_fk = assessment.getCourse_id_fk();
                db.assessmentDao().deleteAssessment(assessment);
                System.out.println("Assessment Deleted");

                Intent intent = new Intent(getApplicationContext(), CourseDetailActivity.class);
                intent.putExtra("courseId", course_id_fk);
                startActivity(intent);
            }
        });

        savebutton = findViewById(R.id.assessment_save_btn);
        savebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    saveAssessment();
                } catch (Exception e)  {

                }
                Snackbar.make(view, "Assessment Updated", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void populateInputs() {

        String assessmentTitle;
        String assessmentType;
        Date assessmentDueDate;
        String patternMonth = "MM";
        String patternDay = "dd";
        String patternYear = "YYYY";
        SimpleDateFormat Month = new SimpleDateFormat(patternMonth);
        SimpleDateFormat Day = new SimpleDateFormat(patternDay);
        SimpleDateFormat Year = new SimpleDateFormat(patternYear);
        db = FullDatabase.getInstance(getApplicationContext());

        int assessment_id = getIntent().getExtras().getInt("assessmentId");
        System.out.println("Extra from previous Activity: " + assessment_id);

        Assessment assessment = db.assessmentDao().getAssessment(assessment_id);

        assessmentTitle = assessment.getAssessment_name();
        assessmentType = assessment.getAssessment_type();
        assessmentDueDate = assessment.getAssessment_due_date();

        System.out.println(assessmentTitle + assessmentDueDate);

        String startMonth = Month.format(assessmentDueDate);
        String startDay = Day.format(assessmentDueDate);
        String startYear = Year.format(assessmentDueDate);


        int startMonthInt = Integer.parseInt(startMonth);
        int startDayInt = Integer.parseInt(startDay);
        int startYearInt = Integer.parseInt(startYear);

        TextView assessmentTitleTextView = findViewById(R.id.edit_assessment_title_test);
        //TextView assessmentTypeTextView = findViewById(R.id.)
        pickerStart=(DatePicker)findViewById(R.id.assessment_due_date);

        assessmentTitleTextView.setText(assessmentTitle);
        pickerStart.init(startYearInt, startMonthInt, startDayInt, null);


    }

    private void saveAssessment() throws ParseException {
        db = FullDatabase.getInstance(getApplicationContext());
        int assessment_id = getIntent().getExtras().getInt("assessmentId");
        System.out.println("Extra from previous Activity: " + assessment_id);
        Assessment assessment = db.assessmentDao().getAssessment(assessment_id);


        CharSequence assessmentTitle;
        TextView assessmentTitleTextView = findViewById(R.id.edit_assessment_title_test);
        assessmentTitle = assessmentTitleTextView.getText();
        StringBuilder sb = new StringBuilder(assessmentTitle.length());
        sb.append(assessmentTitle);
        String assessmentTitleString = sb.toString();
        assessment.setAssessment_name(assessmentTitleString);


        Spinner assessmentTypeSpinner = findViewById(R.id.spinner);
        String item = assessmentTypeSpinner.getSelectedItem().toString();
        System.out.println(item);
        assessment.setAssessment_type(item);


        int day = pickerStart.getDayOfMonth();
        int month = pickerStart.getMonth();
        int year = pickerStart.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);

        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        String formatedDate = sdf.format(calendar.getTime());
        Date date = sdf.parse(formatedDate);
        assessment.setAssessment_due_date(date);
        db.assessmentDao().updateAssessment(assessment);
        System.out.println("Assessment Updated");

        Intent intent = new Intent(getApplicationContext(), AssessmentDetailActivity.class);

        intent.putExtra("assessmentId", assessment_id);
        startActivity(intent);


    }

    private void setDueDateAlarm() {

        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        Intent intent = new Intent(this, MyBroadcastReceiver.class);
        intent.putExtra("AlarmType", "Due Date Alarm");
        int RQS_3 = (int) System.currentTimeMillis();
        pendingIntentDue = PendingIntent.getBroadcast(this, RQS_3, intent, PendingIntent.FLAG_ONE_SHOT);
        int day = pickerStart.getDayOfMonth();
        int month = pickerStart.getMonth();
        int year = pickerStart.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);
        calendar.add(Calendar.MINUTE, 3);


        alarmManager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntentDue);
        System.out.println("This is the time that the alarm is set for: " + calendar.getTime());


    }




}
