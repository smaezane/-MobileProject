package com.example.zanemobilescheduler.Term;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.example.zanemobilescheduler.Course.Course;
import com.example.zanemobilescheduler.Course.CourseDetailActivity;
import com.example.zanemobilescheduler.FullDatabase;

import com.example.zanemobilescheduler.MainActivity;
import com.example.zanemobilescheduler.R;

import com.google.android.material.floatingactionbutton.FloatingActionButton;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class TermDetailActivity extends AppCompatActivity {
    FullDatabase db;
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_term_detail);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        listView = findViewById(R.id.term_detail_list);
        db= FullDatabase.getInstance(getApplicationContext());

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                int terms_id;
                int course_id;

                terms_id = getIntent().getExtras().getInt("termId");
                System.out.println("Extra from previous Activity: " + terms_id);


                List<Course> termDetailActivity = db.courseDao().getCourseList(terms_id);
                for (Course course : termDetailActivity) {
                    System.out.println(course.getCourse_id());
                }

                System.out.println("Position Clicked: " + position);
                course_id = termDetailActivity.get(position).getCourse_id();
                System.out.println("This is the course id you picked" +course_id);

                Intent intent = new Intent(getApplicationContext(), CourseDetailActivity.class);
                intent.putExtra("courseId", course_id);
                System.out.println("course_id at 0: " + course_id);
                startActivity(intent);
            }

        });
        updateList();
        updateLabels();
        Addfab();
        Editfab();



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void Addfab(){
        FloatingActionButton fab = findViewById(R.id.add_course_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int terms_id = getIntent().getExtras().getInt("termId");
                Calendar start;
                Calendar end;
                Course tempCourse1 = new Course();
                List<Term> termList = db.termDao().getTermList();
                if (termList == null) return;

                start = Calendar.getInstance();
                end = Calendar.getInstance();
                end.add(Calendar.MONTH,  +6);
                tempCourse1.setCourse_name("New Course");
                tempCourse1.setCourse_mentor_name("New Mentor");
                tempCourse1.setCourse_mentor_phone("000-0000");
                tempCourse1.setCourse_mentor_email("newMentor@email.com");
                tempCourse1.setCourse_start(start.getTime());
                tempCourse1.setCourse_end(end.getTime());
                tempCourse1.setCourse_notes("Add some class notes...");

                tempCourse1.setCourse_status("Plan to Take");
                tempCourse1.setTerm_id_fk(terms_id);
                db.courseDao().insertCourse(tempCourse1);
                updateList();
            }
        });
    }

    private void Editfab() {
        int terms_id = getIntent().getExtras().getInt("termId");
        System.out.println("Here is your extra in Edit fab " +terms_id);
        final Intent intent = new Intent(getApplicationContext(), TermEditActivity.class);
        intent.putExtra("termId", terms_id);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.edit_term_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(intent);
            }
        });
    }


    private void updateLabels() {
        String termTitle;
        Date startDate;
        Date endDate;
        String pattern = "E, MMM dd, YYYY";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        String date = simpleDateFormat.format(new Date());

        int terms_id = getIntent().getExtras().getInt("termId");
        System.out.println("Here is your extra " +terms_id);
        Term term = db.termDao().getTerm(terms_id);

        Intent intent = new Intent(getApplicationContext(), CourseDetailActivity.class);
        intent.putExtra("termId", terms_id);

        termTitle = term.getTerm_name();
        startDate = term.getTerm_start();
        endDate = term.getTerm_end();

        String startDateFormatted = "Start Date: " + simpleDateFormat.format(startDate);

        String endDateFormatted = "End Date: " + simpleDateFormat.format(endDate);


        TextView termTitleTextView = findViewById(R.id.term_title);
        TextView termStartTextView = findViewById(R.id.term_start);
        TextView termEndTextView = findViewById(R.id.term_end);

        termTitleTextView.setText(termTitle);
        termStartTextView.setText(startDateFormatted);
        termEndTextView.setText(endDateFormatted);

    }






    private void updateList() {



        int terms_id = getIntent().getExtras().getInt("termId");

        System.out.println("Did the extra work?? " + terms_id);


        List<Course> allCourses = db.courseDao().getCourseList(terms_id);
         System.out.println("Number of Rows courses = " + allCourses.size());

        String[] items = new String[allCourses.size()];
        if(!allCourses.isEmpty()) {
            for ( int i = 0; i < allCourses.size(); i++) {
                items[i] = allCourses.get(i).getCourse_name();
                System.out.println("Inside updateList loop courses: " + i);
            }
        }
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, items);
        listView.setAdapter(adapter);
        // adapter.notifyDataSetChanged();
    }
}
