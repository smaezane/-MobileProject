package com.example.zanemobilescheduler.Course;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;

import com.example.zanemobilescheduler.FullDatabase;
import com.example.zanemobilescheduler.MainActivity;
import com.example.zanemobilescheduler.MyBroadcastReceiver;
import com.example.zanemobilescheduler.R;
import com.example.zanemobilescheduler.Term.TermDetailActivity;
import com.google.android.material.snackbar.Snackbar;

import org.w3c.dom.ls.LSOutput;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class CourseEditActivity extends AppCompatActivity {
    FullDatabase db;
    DatePicker pickerStart;
    DatePicker pickerEnd;
    Button deletebutton;
    Button savebutton;
    Button alertStartButton;
    Button alertEndButton;
    public static final int REQUEST_CODE = 101;
    AlarmManager alarmManagerStart;
    AlarmManager alarmManagerEnd;
    PendingIntent pendingIntentStart;
    PendingIntent pendingIntentEnd;
    int course_id;
    int term_id_fk;
    Spinner courseSpinner;


    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.edit_course);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        courseSpinner = (Spinner) findViewById(R.id.course_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.course_spinner_data, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        courseSpinner.setAdapter(adapter);

        alertStartButton = findViewById(R.id.course_alert_start);
        alertStartButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setStartAlarm();
                Snackbar.make(view, "Alarm Set", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });


        alertEndButton = findViewById(R.id.course_alert_end);
        alertEndButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setEndAlarm();
                Snackbar.make(view, "Alarm Set", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();


            }

        });

        deletebutton = findViewById(R.id.course_delete_btn);
        deletebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                db = FullDatabase.getInstance(getApplicationContext());
                course_id = getIntent().getExtras().getInt("courseId");
                System.out.println("Extra from previous Activity: " + course_id);
                Course course = db.courseDao().getCourse(course_id);
                term_id_fk = course.getTerm_id_fk();

                db.courseDao().deleteCourse(course);
                System.out.println("Course Deleted");
                Intent intent = new Intent(getApplicationContext(), TermDetailActivity.class);
                intent.putExtra("termId", term_id_fk);
                startActivity(intent);
            }
        });

        savebutton = findViewById(R.id.course_save_btn);
        savebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    saveCourse();
                } catch (Exception e) {

                }

                Snackbar.make(view, "Course Updated", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        populateInputs();


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void addListenerOnSpinnerItemSelection() {
        // spinner1 = (Spinner) findViewById(R.id.spinner1);
        //spinner1.setOnItemSelectedListener(new CustomOnItemSelectedListener());
    }

    private void populateInputs() {

        String courseTitle;
        Date courseStart;
        Date courseEnd;
        String mentorName;
        String mentorPhone;
        String mentorEmail;
        String patternMonth = "MM";
        String patternDay = "dd";
        String patternYear = "YYYY";
        SimpleDateFormat Month = new SimpleDateFormat(patternMonth);
        SimpleDateFormat Day = new SimpleDateFormat(patternDay);
        SimpleDateFormat Year = new SimpleDateFormat(patternYear);
        db = FullDatabase.getInstance(getApplicationContext());

        int course_id = getIntent().getExtras().getInt("courseId");
        System.out.println("Extra from previous Activity: " + course_id);

        Course course = db.courseDao().getCourse(course_id);

        courseTitle = course.getCourse_name();
        courseStart = course.getCourse_start();
        courseEnd = course.getCourse_end();
        mentorName = course.getCourse_mentor_name();
        mentorPhone = course.getCourse_mentor_phone();
        mentorEmail = course.getCourse_mentor_email();

        System.out.println(courseTitle + courseStart + courseEnd);

        String startMonth = Month.format(courseStart);
        String startDay = Day.format(courseStart);
        String startYear = Year.format(courseStart);
        String endMonth = Month.format(courseEnd);
        String endDay = Day.format(courseEnd);
        String endYear = Year.format(courseEnd);

        int startMonthInt = Integer.parseInt(startMonth);
        int startDayInt = Integer.parseInt(startDay);
        int startYearInt = Integer.parseInt(startYear);
        int endMonthInt = Integer.parseInt(endMonth);
        int endDayInt = Integer.parseInt(endDay);
        int endYearInt = Integer.parseInt(endYear);


        System.out.println(startMonth + startDay + startYear + endMonth + endDay + endYear);
        TextView courseTitleTextView = findViewById(R.id.edit_course_title);
        pickerStart = (DatePicker) findViewById(R.id.date_course_start);
        pickerEnd = (DatePicker) findViewById(R.id.date_course_end);
        TextView courseMentorNameTextView = findViewById(R.id.edit_mentor_name);
        TextView courseMentorPhoneTextView = findViewById(R.id.edit_mentor_phone);
        TextView courseMentorEmailTextView = findViewById(R.id.edit_mentor_email);


        courseTitleTextView.setText(courseTitle);
        pickerStart.init(startYearInt, startMonthInt, startDayInt, null);
        pickerEnd.init(endYearInt, endMonthInt, endDayInt, null);

        courseMentorNameTextView.setText(mentorName);
        courseMentorPhoneTextView.setText(mentorPhone);
        courseMentorEmailTextView.setText(mentorEmail);

        Resources resource = getResources();
        String[] courseArray = resource.getStringArray(R.array.course_spinner_data);

    }

    private void saveCourse() throws ParseException {
        db = FullDatabase.getInstance(getApplicationContext());
        int course_id = getIntent().getExtras().getInt("courseId");
        System.out.println("Extra from previous Activity in CourseSave: " + course_id);
        Course course = db.courseDao().getCourse(course_id);

        CharSequence courseTitle;
        TextView courseTitleTextView = findViewById(R.id.edit_course_title);
        courseTitle = courseTitleTextView.getText();
        StringBuilder sb = new StringBuilder(courseTitle.length());
        sb.append(courseTitle);
        String courseTitleString = sb.toString();
        course.setCourse_name(courseTitleString);

        Spinner courseSpinner = findViewById(R.id.course_spinner);
        String item = courseSpinner.getSelectedItem().toString();
        System.out.println(item);
        course.setCourse_status(item);

        int day = pickerStart.getDayOfMonth();
        int month = pickerStart.getMonth();
        int year = pickerStart.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);

        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        String formatedDate = sdf.format(calendar.getTime());
        Date startDate = sdf.parse(formatedDate);
        course.setCourse_start(startDate);
        System.out.println("Start Date: " +startDate);

        int dayEnd = pickerEnd.getDayOfMonth();
        int monthEnd = pickerEnd.getMonth();
        int yearEnd = pickerEnd.getYear();
        Calendar calendarEnd = Calendar.getInstance();
        calendarEnd.set(yearEnd, monthEnd, dayEnd);

        String formatedDateEnd = sdf.format(calendarEnd.getTime());
        Date EndDate = sdf.parse(formatedDateEnd);
        System.out.println("End Date: " + EndDate);
        course.setCourse_end(EndDate);

        CharSequence mentorName;
        TextView mentorNameTextView = findViewById(R.id.edit_mentor_name);
        mentorName = mentorNameTextView.getText();
        sb = new StringBuilder(mentorName.length());
        sb.append(mentorName);
        String mentorNameString = sb.toString();
        course.setCourse_mentor_name(mentorNameString);

        CharSequence mentorEmail;
        TextView mentorEmailTextView = findViewById(R.id.edit_mentor_email);
        mentorEmail = mentorEmailTextView.getText();
        sb = new StringBuilder(mentorEmail.length());
        sb.append(mentorEmail);
        String mentorEmailString = sb.toString();
        course.setCourse_mentor_email(mentorEmailString);

        CharSequence mentorPhone;
        TextView mentorPhoneTextView = findViewById(R.id.edit_mentor_phone);
        mentorPhone = mentorPhoneTextView.getText();
        sb = new StringBuilder(mentorPhone.length());
        sb.append(mentorPhone);
        String mentorPhoneString = sb.toString();
        course.setCourse_mentor_phone(mentorPhoneString);
        if (course == null) {
            System.out.println("course is null. bummer =(");
        }
        else{
            System.out.println("Course is NOT NULL!!!!!!!");
        }


        db.courseDao().updateCourse(course);
        System.out.println("CourseUpdated");

        Intent intent = new Intent(getApplicationContext(), CourseDetailActivity.class);
        intent.putExtra("courseId", course_id);
        startActivity(intent);


    }

    public void setStartAlarm() {
        alarmManagerStart = (AlarmManager) getSystemService(ALARM_SERVICE);

        Intent intent = new Intent(this, MyBroadcastReceiver.class);
        intent.putExtra("AlarmType", "Course Start Alarm");
        int RQS_1 = (int) System.currentTimeMillis();
        pendingIntentStart = PendingIntent.getBroadcast(this, RQS_1, intent, PendingIntent.FLAG_ONE_SHOT);
        int day = pickerStart.getDayOfMonth();
        int month = pickerStart.getMonth();
        int year = pickerStart.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);
        calendar.add(Calendar.MINUTE, 1);
        alarmManagerStart.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntentStart);
        System.out.println("This is the time that the alarm is set for: " +calendar.getTime());


    }

    public void setEndAlarm() {
        alarmManagerEnd = (AlarmManager) getSystemService(ALARM_SERVICE);



        Intent intent = new Intent(this, MyBroadcastReceiver.class);
        intent.putExtra("AlarmType", "Course End Alarm");

        int RQS_2 = (int) System.currentTimeMillis();
        pendingIntentEnd = PendingIntent.getBroadcast(this, RQS_2, intent, PendingIntent.FLAG_ONE_SHOT);
        int day = pickerEnd.getDayOfMonth();
        int month = pickerEnd.getMonth();
        int year = pickerEnd.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);
        calendar.add(Calendar.MINUTE, 2);
        alarmManagerEnd.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntentEnd);
        System.out.println("This is the time that the alarm is set for: " +calendar.getTime());

    }
}




