package com.example.zanemobilescheduler;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.zanemobilescheduler.Assessment.Assessment;
import com.example.zanemobilescheduler.Course.Course;
import com.google.android.material.snackbar.Snackbar;

import org.w3c.dom.Text;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class NotesActivity extends AppCompatActivity {
    FullDatabase db;
    Button savebutton;
    Button sendSMSButton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_notes);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        savebutton = findViewById(R.id.save_button);
        savebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {

                db = FullDatabase.getInstance(getApplicationContext());
                int course_id = getIntent().getExtras().getInt("courseId");
                System.out.println("Extra from previous Activity: " + course_id);
                Course course = db.courseDao().getCourse(course_id);

                CharSequence updatedNotes;
                TextView notesTextView = findViewById(R.id.edit_notes_text);
                updatedNotes = notesTextView.getText();

                StringBuilder sb = new StringBuilder(updatedNotes.length());
                sb.append(updatedNotes);
                String updatedNotesString = sb.toString();

                try {
                    course.setCourse_notes(updatedNotesString);
                    db.courseDao().updateCourse(course);

                } catch (Exception e) {

                }
                Snackbar.make(view, "Note Saved", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }

        });

        sendSMSButton = findViewById(R.id.send_sms);
        sendSMSButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                TextView textView = (TextView) findViewById(R.id.phone_input);
                String smsNumber = String.format("smsto: %s",
                        textView.getText().toString());
                 EditText smsEditText = (EditText) findViewById(R.id.edit_notes_text);
                String sms = smsEditText.getText().toString();
                Intent smsIntent = new Intent(Intent.ACTION_SENDTO);
                smsIntent.setData(Uri.parse(smsNumber));
                smsIntent.putExtra("sms_body", sms);
                 if (smsIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(smsIntent);
                } else {
                    System.out.println("SMS not sent");
                }
            }

        });


        populateInputs();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }






    private void populateInputs() {

        String Notes;

        db = FullDatabase.getInstance(getApplicationContext());

        int course_id = getIntent().getExtras().getInt("courseId");
        System.out.println("Extra from previous Activity: " + course_id);

        Course course = db.courseDao().getCourse(course_id);
        Notes = course.getCourse_notes();
        TextView notesTextView = findViewById(R.id.edit_notes_text);
        notesTextView.setText(Notes);



    }

}
