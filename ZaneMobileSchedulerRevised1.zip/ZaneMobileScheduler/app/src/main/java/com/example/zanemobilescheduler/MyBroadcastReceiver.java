package com.example.zanemobilescheduler;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

public class MyBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String alarmType = intent.getStringExtra( "AlarmType");
        System.out.println("This alarm type is: " +alarmType);
        NotificationHelper notificationHelper = new NotificationHelper(context);

        if(alarmType.contains("Due")) {
            NotificationCompat.Builder nb1 = notificationHelper.getChannelNotificationDueDate();
            notificationHelper.getManager().notify(1, nb1.build());

        }
        else if (alarmType.contains("Start") ) {
            NotificationCompat.Builder nb2 = notificationHelper.getChannelNotificationCourseStart();
            notificationHelper.getManager().notify(2, nb2.build());
        }
        else if(alarmType.contains("End")){
            NotificationCompat.Builder nb3 = notificationHelper.getChannelNotificationCourseEnd();
            notificationHelper.getManager().notify(3, nb3.build());
        }
        else {
            System.out.println("Your Alarm didn't have an Intent");
        }


    }
}
