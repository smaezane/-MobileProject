package com.example.zanemobilescheduler;

import android.content.Context;


import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.example.zanemobilescheduler.Assessment.Assessment;
import com.example.zanemobilescheduler.Assessment.AssessmentDao;
import com.example.zanemobilescheduler.Course.Course;
import com.example.zanemobilescheduler.Course.CourseDao;
import com.example.zanemobilescheduler.Term.Term;
import com.example.zanemobilescheduler.Term.TermDao;

@Database(entities = {Term.class, Course.class, Assessment.class}, exportSchema = false, version = 3)
@TypeConverters({Converters.class})

public abstract class FullDatabase extends RoomDatabase {

    private static final String DB_NAME = "full_database";
    private static FullDatabase instance;

    public static synchronized FullDatabase getInstance(Context context) {
        if(instance == null){
            instance = Room.databaseBuilder(context.getApplicationContext(), FullDatabase.class, DB_NAME).allowMainThreadQueries().fallbackToDestructiveMigration().build();

        }
        return instance;
    }

    public abstract TermDao termDao();
    public abstract CourseDao courseDao();
    public abstract AssessmentDao assessmentDao();

}