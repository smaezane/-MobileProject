package com.example.zanemobilescheduler;

import android.annotation.TargetApi;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.ContextWrapper;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import java.util.List;

public class NotificationHelper extends ContextWrapper {

    public static final String channelID1 = "channelID";
    public static final String channelID2 = "channelID";
    public static final String channelID3 = "channelID";
    public static final String channelName = "Channel Name";
    private NotificationManager mManager;

    public NotificationHelper(Context base) {
        super(base);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            createChannel();
        }
    }

    @TargetApi(Build.VERSION_CODES.O)

    private void createChannel() {
        NotificationChannel channel1 = new NotificationChannel(channelID1, channelName, NotificationManager.IMPORTANCE_HIGH);
        getManager().createNotificationChannel(channel1);
        NotificationChannel channel2 = new NotificationChannel(channelID2, channelName, NotificationManager.IMPORTANCE_HIGH);
        getManager().createNotificationChannel(channel2);
        NotificationChannel channel3 = new NotificationChannel(channelID3, channelName, NotificationManager.IMPORTANCE_HIGH);
        getManager().createNotificationChannel(channel3);
    }

    public NotificationManager getManager() {
        if (mManager == null) {
            mManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        }
        return mManager;
    }

    public NotificationCompat.Builder getChannelNotificationDueDate() {
        return new NotificationCompat.Builder(getApplicationContext(), channelID1)
                .setContentTitle("WGU Mobile Scheduler Alarm")
                .setContentText("Assessment is past due!")
                .setSmallIcon(R.drawable.notification_icon);
    }

    public NotificationCompat.Builder getChannelNotificationCourseStart() {
        return new NotificationCompat.Builder(getApplicationContext(), channelID2)
                .setContentTitle("WGU Mobile Scheduler Alarm")
                .setContentText("Your Course has started")
                .setSmallIcon(R.drawable.notification_icon);
    }

    public NotificationCompat.Builder getChannelNotificationCourseEnd() {
        return new NotificationCompat.Builder(getApplicationContext(), channelID3)
                .setContentTitle("WGU Mobile Scheduler Alarm")
                .setContentText("Your Course has ended")
                .setSmallIcon(R.drawable.notification_icon);
    }
}