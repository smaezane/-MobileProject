package com.example.zanemobilescheduler.Term;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.example.zanemobilescheduler.Course.Course;
import com.example.zanemobilescheduler.Course.CourseDetailActivity;
import com.example.zanemobilescheduler.FullDatabase;
import com.example.zanemobilescheduler.MainActivity;
import com.example.zanemobilescheduler.R;
import com.example.zanemobilescheduler.TermsListSecondActivity;
import com.google.android.material.snackbar.Snackbar;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class TermEditActivity extends AppCompatActivity {
    FullDatabase db;
    DatePicker pickerStart;
    DatePicker pickerEnd;
    Button deletebutton;
    Button savebutton;



    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_term);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);

        populateInputs();

        savebutton = findViewById(R.id.term_save_btn);
        savebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                try {
                    saveTerm();
                } catch (ParseException e) {

                }

            }

        });

        deletebutton = findViewById(R.id.term_delete_btn);
        deletebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)
            {
                db = FullDatabase.getInstance(getApplicationContext());
                int terms_id = getIntent().getExtras().getInt("termId");
                System.out.println("Extra from previous Activity: " + terms_id);
                Term term = db.termDao().getTerm(terms_id);
                List<Course> allCourses = db.courseDao().getCourseList(terms_id);
                if (allCourses.isEmpty()) {
                    db.termDao().deleteTerm(term);
                    System.out.println("Term Deleted");
                    backToTermsList();
                }
                else {
                    Snackbar.make(view, "Term with existing courses cannot be deleted", Snackbar.LENGTH_LONG)
                            .setAction("Action", null).show();
                }

            }
        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_home) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void populateInputs() {

        String termTitle;
        Date termStart;
        Date termEnd;
        String pattern = "E, MMM dd, YYYY";
        String patternMonth = "MM";
        String patternDay = "dd";
        String patternYear = "YYYY";
        SimpleDateFormat Month = new SimpleDateFormat(patternMonth);
        SimpleDateFormat Day = new SimpleDateFormat(patternDay);
        SimpleDateFormat Year = new SimpleDateFormat(patternYear);
        db = FullDatabase.getInstance(getApplicationContext());

        int terms_id = getIntent().getExtras().getInt("termId");
        System.out.println("Extra from previous Activity: " + terms_id);

        Term term = db.termDao().getTerm(terms_id);

            termTitle = term.getTerm_name();
            termStart = term.getTerm_start();
            termEnd = term.getTerm_end();


            System.out.println(termTitle + termStart + termEnd);
        String startMonth = Month.format(termStart);
        String startDay = Day.format(termStart);
        String startYear = Year.format(termStart);
        String endMonth = Month.format(termEnd);
        String endDay = Day.format(termEnd);
        String endYear = Year.format(termEnd);

        int startMonthInt = Integer.parseInt(startMonth);
        int startDayInt = Integer.parseInt(startDay);
        int startYearInt = Integer.parseInt(startYear);
        int endMonthInt = Integer.parseInt(endMonth);
        int endDayInt = Integer.parseInt(endDay);
        int endYearInt = Integer.parseInt(endYear);


            TextView termTitleTextView = findViewById(R.id.edit_term_title);
            pickerStart=(DatePicker)findViewById(R.id.date_term_start);
            pickerEnd=(DatePicker)findViewById(R.id.date_term_end);


            termTitleTextView.setText(termTitle);
        pickerStart.init(startYearInt, startMonthInt, startDayInt, null);
        pickerEnd.init(endYearInt, endMonthInt, endDayInt, null);


    }
    private void backToTermsList(){
        Intent intent = new Intent(getApplicationContext(), TermsListSecondActivity.class);
        startActivity(intent);

    }

    private void saveTerm() throws ParseException {
        db = FullDatabase.getInstance(getApplicationContext());
        int terms_id = getIntent().getExtras().getInt("termId");
        System.out.println("Extra from previous Activity: " + terms_id);
        Term term = db.termDao().getTerm(terms_id);
        String pattern = "E, MMM dd, YYYY";
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        CharSequence termTitle;
        TextView termTitleTextView = findViewById(R.id.edit_term_title);
        termTitle = termTitleTextView.getText();
        StringBuilder sb = new StringBuilder(termTitle.length());
        sb.append(termTitle);
        String termTitleString = sb.toString();
        term.setTerm_name(termTitleString);

        int day = pickerStart.getDayOfMonth();
        int month = pickerStart.getMonth();
        int year = pickerStart.getYear();
        Calendar calendar = Calendar.getInstance();
        calendar.set(year, month, day);

        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        String formatedDate = sdf.format(calendar.getTime());
        Date startDate = sdf.parse(formatedDate);
        term.setTerm_start(startDate);

        int dayEnd = pickerEnd.getDayOfMonth();
        int monthEnd = pickerEnd.getMonth();
        int yearEnd = pickerEnd.getYear();
        Calendar calendarEnd = Calendar.getInstance();
        calendarEnd.set(yearEnd, monthEnd, dayEnd);

        String formatedDateEnd = sdf.format(calendarEnd.getTime());
        Date EndDate = sdf.parse(formatedDateEnd);
        term.setTerm_end(EndDate);


        db.termDao().updateTerm(term);
        System.out.println("Term Updated");
        backToTermsList();


    }
    }

