package com.example.zanemobilescheduler;


import android.content.Context;

import androidx.appcompat.app.AppCompatActivity;

import com.example.zanemobilescheduler.Assessment.Assessment;
import com.example.zanemobilescheduler.Course.Course;
import com.example.zanemobilescheduler.Term.Term;

import java.util.Calendar;
import java.util.List;

public class PopulateFullDatabase extends AppCompatActivity {
    public static String LOG_TAG = "popData";
    Term tempTerm1 = new Term();
    Term tempTerm2 = new Term();
    Term tempTerm3 = new Term();
    Course tempCourse1 = new Course();
    Course tempCourse2 = new Course();
    Course tempCourse3 = new Course();
    Course tempCourse4 = new Course();
    Course tempCourse5 = new Course();
    Course tempCourse6 = new Course();
    Course tempCourse7 = new Course();
    Course tempCourse8 = new Course();
    Course tempCourse9 = new Course();
    Course tempCourse10 = new Course();
    Course tempCourse11 = new Course();
    Assessment tempAssessment1 = new Assessment();
    Assessment tempAssessment2 = new Assessment();
    Assessment tempAssessment3 = new Assessment();
    Assessment tempAssessment4 = new Assessment();
    Assessment tempAssessment5 = new Assessment();
    Assessment tempAssessment6 = new Assessment();
    Assessment tempAssessment7 = new Assessment();
    Assessment tempAssessment8 = new Assessment();
    Assessment tempAssessment9 = new Assessment();
    Assessment tempAssessment10 = new Assessment();
    Assessment tempAssessment11 = new Assessment();

    FullDatabase db;


    public void populate(Context context) {
        db = FullDatabase.getInstance(context);
        try{
            insertTerms();
            insertCourses();
            insertAssessment();
            System.out.println("Inserts Successful");
        }
        catch (Exception e) {
            e.printStackTrace();
            // log.d(LOG_TAG, msg: "Populate Database Failed");
        }

    }

    public void insertTerms(){
        Calendar start;
        Calendar end;

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH,  -11);
        end.add(Calendar.MONTH, -6);
        tempTerm1.setTerm_name("Fall 2019");
        tempTerm1.setTerm_start(start.getTime());
        tempTerm1.setTerm_end(end.getTime());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, -5);
        end.add(Calendar.MONTH,  0);
        tempTerm2.setTerm_name("Spring 2020");
        tempTerm2.setTerm_start(start.getTime());
        tempTerm2.setTerm_end(end.getTime());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, 1);
        end.add(Calendar.MONTH, 6 );
        tempTerm3.setTerm_name("Fall 2020");
        tempTerm3.setTerm_start(start.getTime());
        tempTerm3.setTerm_end(end.getTime());

        db.termDao().insertAll(tempTerm1, tempTerm2, tempTerm3);
        System.out.println("Terms inserted");

    }

    private void insertCourses() {
        Calendar start;
        Calendar end;
        List<Term> termList = db.termDao().getTermList();
        if (termList == null) return;

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, -11);
        end.add(Calendar.MONTH,  -6);
        tempCourse1.setCourse_name("Transfiguration");
        tempCourse1.setCourse_mentor_name("Minerva Mcgonagal");
        tempCourse1.setCourse_mentor_phone("555-1111");
        tempCourse1.setCourse_mentor_email("MeowMeow@Hogwarts.edu");
        tempCourse1.setCourse_start(start.getTime());
        tempCourse1.setCourse_end(end.getTime());
        tempCourse1.setCourse_notes("Transfiguration in History\n" +
                "\n" +
                "Origin of Transfiguration\n" +
                "\n" +
                "Transfiguration is a newer branch of magic\n" +
                "It wasn't always seen as the scientific practice it is now but it always was there in nature\n" +
                "The first records of transfiguration were considered very advanced and could only be done by very, very few with great talent");

        tempCourse1.setCourse_status("Completed");
        tempCourse1.setTerm_id_fk(termList.get(0).getTerm_id());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, -11);
        end.add(Calendar.MONTH,  -6);
        tempCourse2.setCourse_name("Charms");
        tempCourse2.setCourse_mentor_name("Filius Flitwick");
        tempCourse2.setCourse_mentor_phone("555-2222");
        tempCourse2.setCourse_mentor_email("Leviosa@Hogwarts.edu");
        tempCourse2.setCourse_start(start.getTime());
        tempCourse2.setCourse_end(end.getTime());
        tempCourse2.setCourse_notes("Mending Charm (Reparo):\n" +
                "Created around approximately 1754 by Orabella Nuttley. It was used it\n" +
                "to repair the Colosseum. Simply say the proper incantation and make the\n" +
                "correct wand gesture while picturing the item as undamaged. It doesn’t\n" +
                "require a great deal of power or effort for most repairs but it\n" +
                "demonstrates how continuous wand movement works.");

        tempCourse2.setCourse_status("Completed");
        tempCourse2.setTerm_id_fk(termList.get(0).getTerm_id());


        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, -11);
        end.add(Calendar.MONTH,  -6);
        tempCourse3.setCourse_name("Potions");
        tempCourse3.setCourse_mentor_name("Severus Snape");
        tempCourse3.setCourse_mentor_phone("555-3333");
        tempCourse3.setCourse_mentor_email("Always@Hogwarts.edu");
        tempCourse3.setCourse_start(start.getTime());
        tempCourse3.setCourse_end(end.getTime());
        tempCourse3.setCourse_notes("First Potions Class\n" +
                "Description:\n" +
                "bewitch the mind\n" +
                "ensnare the senses\n" +
                "bottle fame\n" +
                "brew glory\n" +
                "put a stopper in death.\n");
        tempCourse3.setCourse_status("Completed");
        tempCourse3.setTerm_id_fk(termList.get(0).getTerm_id());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, -11);
        end.add(Calendar.MONTH,  -6);
        tempCourse4.setCourse_name("History of Magic");
        tempCourse4.setCourse_mentor_name("Cuthbert Binns");
        tempCourse4.setCourse_mentor_phone("555-4444");
        tempCourse4.setCourse_mentor_email("IAmAGhost@Hogwarts.edu");
        tempCourse4.setCourse_start(start.getTime());
        tempCourse4.setCourse_end(end.getTime());
        tempCourse4.setCourse_notes("Uric the Oddball\n" +
                "Description:\n" +
                "Uric the Oddball was a medieval wizard, who became famous for his eccentric behaviour, such as wearing a jellyfish as a hat, and sleeping in a room with fifty pet Augureys. He is considered to be one of the weirdest wizards in history, and, as such, is often the punchline of wizarding jokes\n");
        tempCourse4.setCourse_status("Completed");
        tempCourse4.setTerm_id_fk(termList.get(0).getTerm_id());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, -5);
        end.add(Calendar.MONTH,  0);
        tempCourse5.setCourse_name("Arithmancy");
        tempCourse5.setCourse_mentor_name("Septima Vctor");
        tempCourse5.setCourse_mentor_phone("555-5555");
        tempCourse5.setCourse_mentor_email("Numbers@Hogwarts.edu");
        tempCourse5.setCourse_start(start.getTime());
        tempCourse5.setCourse_end(end.getTime());
        tempCourse5.setCourse_notes("Bridget Wenlock\n" +
                "Description:\n" +
                "The archetypal example; she was a celebrated witch who first discovered the magical properties of the number seven in the 13th century.\n");
        tempCourse5.setCourse_status("Completed");
        tempCourse5.setTerm_id_fk(termList.get(1).getTerm_id());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, -5);
        end.add(Calendar.MONTH,  -0);
        tempCourse6.setCourse_name("Muggle Studies");
        tempCourse6.setCourse_mentor_name("Charity Burbage");
        tempCourse6.setCourse_mentor_phone("555-6666");
        tempCourse6.setCourse_mentor_email("MuggleAlly@Hogwarts.edu");
        tempCourse6.setCourse_start(start.getTime());
        tempCourse6.setCourse_end(end.getTime());
        tempCourse6.setCourse_notes("Muggle Social Media\n" +
                "Description:\n" +
                "Snapchat: Although Howlers are not an exact equivalent, their transient nature is a key part of the “Social Media,” Snapchat. Snapchat is another way to message a friend through text or image, but the messages only last a short period of time. Just as a Howler burst into flames upon delivery of its message, Snapchat ceases to exist after a twenty-four hour period. Younger Muggles have taken to futilely recording every moment of their lives with this technology only to allow them to disappear into dust once more after the allotted time.");
        tempCourse6.setCourse_status("Completed");
        tempCourse6.setTerm_id_fk(termList.get(1).getTerm_id());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, -5);
        end.add(Calendar.MONTH,  -0);
        tempCourse7.setCourse_name("Divination");
        tempCourse7.setCourse_mentor_name("Sybil Trelawny");
        tempCourse7.setCourse_mentor_phone("555-7777");
        tempCourse7.setCourse_mentor_email("SeeTheFuture@Hogwarts.edu");
        tempCourse7.setCourse_start(start.getTime());
        tempCourse7.setCourse_end(end.getTime());
        tempCourse7.setCourse_notes("First Potions Class\n" +
                "Description:\n" +
                "There are a myriad of ways to scry information about the future, including tea dregs, crystal balls, visions, and Astrology and horoscope charts. Other methods of divining the future include smoke patterns, dreams, tarot cards, and the interpretation of prophecies, though the latter is quite rare");
        tempCourse7.setCourse_status("In Progress");
        tempCourse7.setTerm_id_fk(termList.get(1).getTerm_id());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, -5);
        end.add(Calendar.MONTH,  -0);
        tempCourse8.setCourse_name("Ancient Runes");
        tempCourse8.setCourse_mentor_name("Bathsheda Babbling");
        tempCourse8.setCourse_mentor_phone("555-8888");
        tempCourse8.setCourse_mentor_email("AncientLady@Hogwarts.edu");
        tempCourse8.setCourse_start(start.getTime());
        tempCourse8.setCourse_end(end.getTime());
        tempCourse8.setCourse_notes("Numbers:\n" +
                "Description:\n" +
                "Demiguise: the creature's invisibility abilities represents \"0\".\n" +
                "Unicorn: the creature's single horn represents \"1\".\n" +
                "Graphorn: the creature's dual horns represent \"2\".\n" +
                "Runespoor: the triple-headed creature represents \"3\".\n" +
                "Fwooper: the creature comprised of four different colours in feathers represents \"4\".\n");
        tempCourse8.setCourse_status("In Progress");
        tempCourse8.setTerm_id_fk(termList.get(1).getTerm_id());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, 1);
        end.add(Calendar.MONTH,  6);
        tempCourse9.setCourse_name("Care of Magical Creatures");
        tempCourse9.setCourse_mentor_name("Rubeus Hagrid");
        tempCourse9.setCourse_mentor_phone("555-9999");
        tempCourse9.setCourse_mentor_email("CreatureTeacher@Hogwarts.edu");
        tempCourse9.setCourse_start(start.getTime());
        tempCourse9.setCourse_end(end.getTime());
        tempCourse9.setCourse_notes("\n" +
                "Description:\n" +
                "A Hippogriff was a magical beast that had the front legs, wings, and head of a giant eagle and the body, hind legs and tail of a horse. It was very similar to another magical creature, the Griffin, with the horse rear replacing the lion rear.");
        tempCourse9.setCourse_status("Plan to Take");
        tempCourse9.setTerm_id_fk(termList.get(2).getTerm_id());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, 1);
        end.add(Calendar.MONTH,  6);
        tempCourse10.setCourse_name("Defense Against the Dark Arts");
        tempCourse10.setCourse_mentor_name("Gilderoy Lockheart");
        tempCourse10.setCourse_mentor_phone("555-2210");
        tempCourse10.setCourse_mentor_email("MagicalMe@Hogwarts.edu");
        tempCourse10.setCourse_start(start.getTime());
        tempCourse10.setCourse_end(end.getTime());
        tempCourse10.setCourse_notes("First Defense Against the Dark Arts Class\n" +
                "Description:");
        tempCourse10.setCourse_status("Plan to Take");
        tempCourse10.setTerm_id_fk(termList.get(2).getTerm_id());

        start = Calendar.getInstance();
        end = Calendar.getInstance();
        start.add(Calendar.MONTH, 1);
        end.add(Calendar.MONTH,  6);
        tempCourse11.setCourse_name("Herbology");
        tempCourse11.setCourse_mentor_name("Pomona Sprout");
        tempCourse11.setCourse_mentor_phone("555-2211");
        tempCourse11.setCourse_mentor_email("HufflepuffMomma@Hogwarts.edu");
        tempCourse11.setCourse_start(start.getTime());
        tempCourse11.setCourse_end(end.getTime());
        tempCourse11.setCourse_notes("Mandrakes\n" +
                "Description:/n " +
                "A Mandrake, also known as Mandragora, is a magical and sentient plant which has a root that looks like a human (like a baby when the plant is young, but maturing as the plant grows). When matured, its cry can be fatal to any person who hears it");
        tempCourse11.setCourse_status("Plan to Take");
        tempCourse11.setTerm_id_fk(termList.get(2).getTerm_id());


        db.courseDao().insertAll(tempCourse1, tempCourse2, tempCourse3, tempCourse4, tempCourse5, tempCourse6, tempCourse7, tempCourse8, tempCourse9, tempCourse10, tempCourse11);



    }
    private void insertAssessment(){
        Calendar end;
        List<Course> courseList = db.courseDao().getCourseList();
        if (courseList == null) return;


        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  -6);
        tempAssessment1.setAssessment_name("Transfiguarion Performance Assessment");
        tempAssessment1.setAssessment_type("Performance");
        tempAssessment1.setAssessment_due_date(end.getTime());
        tempAssessment1.setAssessment_status("Passed");
        tempAssessment1.setCourse_id_fk(courseList.get(0).getCourse_id());


        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  -6);
        tempAssessment2.setAssessment_name("Charms Performance Assessment");
        tempAssessment2.setAssessment_type("Performance");
        tempAssessment2.setAssessment_due_date(end.getTime());
        tempAssessment2.setAssessment_status("Passed");
        tempAssessment2.setCourse_id_fk(courseList.get(1).getCourse_id());


        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  -6);
        tempAssessment3.setAssessment_name("Potions Performance Assessment");
        tempAssessment3.setAssessment_type("Performance");
        tempAssessment3.setAssessment_due_date(end.getTime());
        tempAssessment3.setAssessment_status("Passed");
        tempAssessment3.setCourse_id_fk(courseList.get(2).getCourse_id());


        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  -6);
        tempAssessment4.setAssessment_name("History of Magic Objective Assessment");
        tempAssessment4.setAssessment_type("Objective");
        tempAssessment4.setAssessment_due_date(end.getTime());
        tempAssessment4.setAssessment_status("Passed");
        tempAssessment4.setCourse_id_fk(courseList.get(3).getCourse_id());


        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  0);
        tempAssessment5.setAssessment_name("Arithmancy Objective Assessment");
        tempAssessment5.setAssessment_type("Objective");
        tempAssessment5.setAssessment_due_date(end.getTime());
        tempAssessment5.setAssessment_status("Passed");
        tempAssessment5.setCourse_id_fk(courseList.get(4).getCourse_id());


        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  0);
        tempAssessment6.setAssessment_name("Muggle Studies Objective Assessment");
        tempAssessment6.setAssessment_type("Objective");
        tempAssessment6.setAssessment_due_date(end.getTime());
        tempAssessment6.setAssessment_status("Pending");
        tempAssessment6.setCourse_id_fk(courseList.get(5).getCourse_id());

        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  0);
        tempAssessment7.setAssessment_name("Divination Performance Assessment");
        tempAssessment7.setAssessment_type("Performance");
        tempAssessment7.setAssessment_due_date(end.getTime());
        tempAssessment7.setAssessment_status("Pending");
        tempAssessment7.setCourse_id_fk(courseList.get(6).getCourse_id());

        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  0);
        tempAssessment8.setAssessment_name("Ancient Runes Objective Assessment");
        tempAssessment8.setAssessment_type("Objective");
        tempAssessment8.setAssessment_due_date(end.getTime());
        tempAssessment8.setAssessment_status("Pending");
        tempAssessment8.setCourse_id_fk(courseList.get(7).getCourse_id());


        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  6);
        tempAssessment9.setAssessment_name("Care of Magical Creatures PerformanceAssessment");
        tempAssessment9.setAssessment_type("Performance");
        tempAssessment9.setAssessment_due_date(end.getTime());
        tempAssessment9.setAssessment_status("Pending");
        tempAssessment9.setCourse_id_fk(courseList.get(8).getCourse_id());


        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  6);
        tempAssessment10.setAssessment_name("Defense Against the Dark Arts objective Assessment");
        tempAssessment10.setAssessment_type("Objective");
        tempAssessment10.setAssessment_due_date(end.getTime());
        tempAssessment10.setAssessment_status("Pending");
        tempAssessment10.setCourse_id_fk(courseList.get(9).getCourse_id());


        end = Calendar.getInstance();
        end.add(Calendar.MONTH,  6);
        tempAssessment11.setAssessment_name("Herbology Objective Assessment");
        tempAssessment11.setAssessment_type("Objective");
        tempAssessment11.setAssessment_due_date(end.getTime());
        tempAssessment11.setAssessment_status("Pending");
        tempAssessment11.setCourse_id_fk(courseList.get(10).getCourse_id());

        db.assessmentDao().insertAssessment(tempAssessment1);
        db.assessmentDao().insertAssessment(tempAssessment2);
        db.assessmentDao().insertAssessment(tempAssessment3);
        db.assessmentDao().insertAssessment(tempAssessment4);
        db.assessmentDao().insertAssessment(tempAssessment5);
        db.assessmentDao().insertAssessment(tempAssessment6);
        db.assessmentDao().insertAssessment(tempAssessment7);
        db.assessmentDao().insertAssessment(tempAssessment8);
        db.assessmentDao().insertAssessment(tempAssessment9);
        db.assessmentDao().insertAssessment(tempAssessment10);
        db.assessmentDao().insertAssessment(tempAssessment11);







    }



}
